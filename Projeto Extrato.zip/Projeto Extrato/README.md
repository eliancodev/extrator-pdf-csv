# Projeto de Extração de Dados de PDFs

Este projeto realiza a extração de dados de arquivos PDF e os converte em arquivos CSV formatados.
## Estrutura
- `data/input/`: PDFs de entrada
- `data/output/`: CSVs gerados
- `src/`: Código fonte do projeto
- `tests/`: Testes unitários
- `main.py`: Script principal para rodar o projeto
