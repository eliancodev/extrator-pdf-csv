"""
Script principal: extração e processamento de dados de PDFs para CSV.
"""

from pathlib import Path
import pandas as pd
from src.extrator import extrair_tabelas
from src.processador import processar_tabelas

# Caminhos e configurações
INPUT_DIR = Path("input/data")
OUTPUT_DIR = Path("output")
RESULTADO_CSV = "transacoes_formatadas.csv"


def salvar_csv(dataframe: pd.DataFrame, caminho_saida: Path) -> None:
    """
    Salva um DataFrame como CSV.

    Args:
        dataframe (pd.DataFrame): Dados estruturados.
        caminho_saida (Path): Caminho completo do arquivo CSV.
    """
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    dataframe.to_csv(caminho_saida, index=False, encoding="utf-8-sig", sep=";")
    print(f"✅ Arquivo CSV salvo em: {caminho_saida}")


def main() -> None:
    """
    Executa o fluxo principal:
    - Extrai tabelas
    - Processa dados
    - Salva em CSV
    """
    tabelas = extrair_tabelas(INPUT_DIR)
    df_tabelas = processar_tabelas(tabelas)
    salvar_csv(df_tabelas, OUTPUT_DIR / RESULTADO_CSV)


if __name__ == "__main__":
    main()
