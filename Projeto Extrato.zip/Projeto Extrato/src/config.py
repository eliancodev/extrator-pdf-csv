"""
Este módulo contém as configurações do projeto, como os caminhos de entrada e saída.
"""

from pathlib import Path

# Caminhos de entrada e saída
INPUT_DIR = Path("data/input")
OUTPUT_DIR = Path("data/output")
