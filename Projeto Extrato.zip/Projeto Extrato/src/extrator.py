"""
Módulo de extração de tabelas de arquivos PDF.
"""

from pathlib import Path
from typing import Any
import pdfplumber


def extrair_tabelas(pasta_entrada: Path) -> list[list[Any]]:
    """
    Extrai tabelas de todos os arquivos PDF em uma pasta.

    Args:
        pasta_entrada (Path): Caminho para a pasta contendo os arquivos PDF.

    Returns:
        list: Lista de tabelas extraídas de cada página dos PDFs.
    """
    tabelas_extraidas: list[list[Any]] = []

    for pdf_file in pasta_entrada.glob("*.pdf"):
        print(f"📄 Lendo: {pdf_file.name}")
        try:
            with pdfplumber.open(pdf_file) as pdf:
                for pagina in pdf.pages:
                    tabelas = pagina.extract_tables({
                        "vertical_strategy": "lines",
                        "horizontal_strategy": "lines",
                        "intersection_tolerance": 5,
                    })
                    if tabelas:
                        print(f"✅ Tabelas encontradas na página {pagina.page_number}")
                        for tabela in tabelas:
                            if tabela:
                                tabelas_extraidas.append(tabela)
                    else:
                        print(f"⚠️ Nenhuma tabela na página {pagina.page_number}")
        except (FileNotFoundError, OSError) as e:
            print(f"⚠️ Erro ao processar {pdf_file.name}: {e}")

    return tabelas_extraidas
