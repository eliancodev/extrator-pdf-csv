"""
Módulo de processamento de textos ou tabelas extraídos de arquivos PDF.
"""

from typing import Any
import pandas as pd


def processar_textos(textos: list[str]) -> pd.DataFrame:
    """
    Processa textos extraídos e converte em DataFrame.

    Args:
        textos (list): Lista de textos dos PDFs.

    Returns:
        pd.DataFrame: Dados estruturados.
    """
    dados = [linha.split() for texto in textos for linha in texto.split("\n")]
    return pd.DataFrame(dados)


def processar_tabelas(tabelas: list[list[list[str]]]) -> pd.DataFrame:
    """
    Processa listas de tabelas em DataFrame com colunas formatadas.

    Args:
        tabelas (list): Tabelas extraídas.

    Returns:
        pd.DataFrame: Dados estruturados com colunas nomeadas.
    """
    dados_formatados: list[list[Any]] = []

    for tabela in tabelas:
        for linha in tabela:
            if not linha or len(linha) < 5:
                continue

            linha = [col.strip() if col else "" for col in linha]

            try:
                data = linha[0]
                detalhes = linha[1]
                valor = float(linha[2].replace(",", "."))
                saldo = float(linha[3].replace(",", "."))
                saldo_sacavel = float(linha[4].replace(",", "."))

                dados_formatados.append([data, detalhes, valor, saldo, saldo_sacavel])
            except (ValueError, IndexError):
                continue

    colunas = ["Data", "Detalhes", "Valor", "Saldo", "Saldo_Sacavel"]
    return pd.DataFrame(dados_formatados, columns=colunas)
