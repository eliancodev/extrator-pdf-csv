# Script principal de execução do projeto
