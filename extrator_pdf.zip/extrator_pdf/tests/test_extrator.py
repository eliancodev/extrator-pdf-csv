# Testes para extrator
