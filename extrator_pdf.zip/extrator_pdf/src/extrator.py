#!/usr/bin/env python
# coding: utf-8

# ## Projeto de análise de dados
# 
#     O projeto consiste em importar dois arquivos no formato PDF que apresenta tabelas contendo informações financeiras em um periodo de 180 dias.
# 
# ## Metodologia Aplicada

# In[2]:


get_ipython().system('pip install pdfplumber pandas')


# In[10]:


import glob
import os

# Caminho absoluto da pasta
pasta = r"C:\Users\Elias\OneDrive - GRUPO EQUATORIAL ENERGIA\Documentos\Documentos\Projetos de Análise de Dados\Projeto Extrato\PDF's"

# Lista os PDFs na pasta
arquivos_pdf = glob.glob(os.path.join(pasta, "*.pdf"))

# Mostra o nome de cada arquivo encontrado
for arquivo in arquivos_pdf:
    print(arquivo)


# In[29]:


import pdfplumber

# Caminho completo do arquivo
caminho_pdf = r"C:\Users\Elias\OneDrive - GRUPO EQUATORIAL ENERGIA\Documentos\Documentos\Projetos de Análise de Dados\Projeto Extrato\PDF's\01112024a17012025.pdf"

with pdfplumber.open(caminho_pdf) as pdf:
    pagina = pdf.pages[0]
    texto = pagina.extract_text()
    linhas = texto.split('\n')

    # Mostra todas as linhas com o índice
    for i, linha in enumerate(linhas):
        print(f"{i:02d}: {linha}")


# In[30]:


import pdfplumber
import pandas as pd
import os
import re

# Caminho da pasta dos PDFs
pasta_pdfs = "PDF's"
transacoes = []

# Percorre os arquivos PDF
for nome_arquivo in os.listdir(pasta_pdfs):
    if nome_arquivo.endswith(".pdf"):
        caminho_pdf = os.path.join(pasta_pdfs, nome_arquivo)

        with pdfplumber.open(caminho_pdf) as pdf:
            for pagina in pdf.pages:
                texto = pagina.extract_text()
                if not texto:
                    continue

                linhas = texto.split('\n')
                i = 0
                while i < len(linhas):
                    # Pega a data e verifica se a próxima linha existe
                    if re.match(r"\d{2}/\d{2}/\d{4}", linhas[i]) and i + 1 < len(linhas):
                        data = linhas[i].strip()
                        detalhes = linhas[i+1].strip()
                        transacoes.append(f"{data} {detalhes}")
                        i += 2  # pula a próxima linha porque já foi usada
                    else:
                        i += 1

# Exibe as 10 primeiras transações completas
for linha in transacoes[:10]:
    print(linha)


# In[39]:


import pdfplumber
import pandas as pd
import os
import re

# Caminho completo do primeiro PDF
caminho_pdf_unico = r"C:\Users\Elias\OneDrive - GRUPO EQUATORIAL ENERGIA\Documentos\Documentos\Projetos de Análise de Dados\Projeto Extrato\PDF's\17012025a17042025.pdf"

# Caminho da pasta contendo os PDFs
pasta_pdfs = r"C:\Users\Elias\OneDrive - GRUPO EQUATORIAL ENERGIA\Documentos\Documentos\Projetos de Análise de Dados\Projeto Extrato\PDF's"

# Exibir as linhas da primeira página do PDF único com índice
print("### Primeira página do PDF selecionado ###\n")
with pdfplumber.open(caminho_pdf_unico) as pdf:
    pagina = pdf.pages[0]
    texto = pagina.extract_text()
    linhas = texto.split('\n')

    for i, linha in enumerate(linhas):
        print(f"{i:02d}: {linha}")

# Agora vamos percorrer todos os PDFs da pasta para extrair transações
transacoes = []

print("\n### Extraindo transações de todos os PDFs ###\n")
for nome_arquivo in os.listdir(pasta_pdfs):
    if nome_arquivo.endswith(".pdf"):
        caminho_pdf = os.path.join(pasta_pdfs, nome_arquivo)

        with pdfplumber.open(caminho_pdf) as pdf:
            for pagina in pdf.pages:
                texto = pagina.extract_text()
                if not texto:
                    continue

                linhas = texto.split('\n')
                i = 0
                while i < len(linhas):
                    if re.match(r"\d{2}/\d{2}/\d{4}", linhas[i]) and i + 1 < len(linhas):
                        data = linhas[i].strip()
                        detalhes = linhas[i + 1].strip()
                        transacoes.append(f"{data} {detalhes}")
                        i += 2
                    else:
                        i += 1

# Exibe as 10 primeiras transações
print("### 10 primeiras transações encontradas ###\n")
for linha in transacoes[:10]:
    print(linha)


# In[ ]:


import pandas as pd

# Transforma a lista de transações em um DataFrame
df_transacoes = pd.DataFrame(transacoes, columns=["Transacao"])

# Divide a coluna em duas: Data e Detalhes (usando a primeira parte como data e o restante como descrição)
df_transacoes[['Data', 'Detalhes']] = df_transacoes['Transacao'].str.extract(r"(\d{2}/\d{2}/\d{4})\s+(.*)")

# Remove a coluna original combinada
df_transacoes.drop(columns=["Transacao"], inplace=True)

# Salva no Excel
caminho_excel = os.path.join(pasta_pdfs, "transacoes_extraidas.xlsx") # Para salvar as transações em um arquivo CSV, o processo é praticamente igual 
                                                                      # ao do Excel, só muda o método de exportação: usamos .to_csv() em vez de .to_excel().
df_transacoes.to_excel(caminho_excel, index=False)

print(f"\nArquivo Excel salvo em: {caminho_excel}")


# In[ ]:





# In[45]:


import pandas as pd
import re
import os

# Transforma a lista de transações em um DataFrame
df_transacoes = pd.DataFrame(transacoes, columns=["Transacao"])

# Extrai a data e o restante da linha
df_transacoes[['Data', 'Detalhes_Completa']] = df_transacoes['Transacao'].str.extract(r"(\d{2}/\d{2}/\d{4})\s+(.*)")

# Função flexível para extrair detalhes e valores
def extrair_detalhes(linha):
    # Encontra todos os valores monetários (R$ x,xx)
    valores = re.findall(r"R\$\s?[\d.,]+", linha)
    
    # Remove os valores do texto para obter apenas os detalhes
    texto_limpo = re.sub(r"(R\$\s?[\d.,]+\s*)+", "", linha).strip()
    
    # Preenche conforme a quantidade de valores encontrados
    valor = saldo = saldo_sacavel = ''
    if len(valores) == 1:
        valor = valores[0]
    elif len(valores) == 2:
        valor, saldo = valores
    elif len(valores) >= 3:
        valor, saldo, saldo_sacavel = valores[:3]
    
    return pd.Series([texto_limpo, valor, saldo, saldo_sacavel])

# Aplica a função
df_transacoes[['Detalhes', 'Valor', 'Saldo', 'Saldo_Sacavel']] = df_transacoes['Detalhes_Completa'].apply(extrair_detalhes)

# Remove a coluna original combinada
df_transacoes.drop(columns=['Transacao', 'Detalhes_Completa'], inplace=True)

# Formata os valores numéricos
for col in ['Valor', 'Saldo', 'Saldo_Sacavel']:
    df_transacoes[col] = (
        df_transacoes[col]
        .str.replace('.', '', regex=False)
        .str.replace(',', '.', regex=False)
        .str.replace('R$', '', regex=False)
        .str.strip()
    )
    # Converte para float, trata erro se estiver vazio
    df_transacoes[col] = pd.to_numeric(df_transacoes[col], errors='coerce')

# Salva o CSV
caminho_csv = os.path.join(pasta_pdfs, "transacoes_formatadas_corrigido.csv")
df_transacoes.to_csv(caminho_csv, index=False, encoding='utf-8-sig', sep=';')

print(f"\nArquivo CSV formatado corretamente salvo em: {caminho_csv}")

