# Funções para limpeza e formatação dos dados
