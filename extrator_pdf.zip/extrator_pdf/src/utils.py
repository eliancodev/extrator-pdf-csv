# Funções auxiliares
